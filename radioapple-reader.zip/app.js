(function () {
  'use strict';
  const story = window.RADIOAPPLE_STORY;
  const $ = (id) => document.getElementById(id);
  const storageKey = 'radioapple-reader:settings:v1';
  let settings = { fontSize: 16, theme: 'light' };
  try { settings = { ...settings, ...JSON.parse(localStorage.getItem(storageKey) || '{}') }; } catch (_) {}
  settings.fontSize = Math.min(23, Math.max(13, Number(settings.fontSize) || 16));
  settings.theme = settings.theme === 'dark' ? 'dark' : 'light';

  function saveSettings() {
    try { localStorage.setItem(storageKey, JSON.stringify(settings)); } catch (_) {}
  }
  function updateSettings() {
    document.documentElement.dataset.theme = settings.theme;
    document.documentElement.style.setProperty('--reader-font-size', `${settings.fontSize}px`);
    $('theme-toggle').textContent = settings.theme === 'light' ? 'Dark mode' : 'Light mode';
    saveSettings();
  }
  function text(id, value) { $(id).textContent = value; }
  function appendText(node, value, className) {
    const p = document.createElement('p');
    p.textContent = value;
    if (className) p.className = className;
    node.appendChild(p);
  }

  function populateMetadata() {
    text('work-title', story.title);
    text('chapter-work-title', story.title);
    text('breadcrumb-title', story.title);
    text('work-author', story.author);
    text('chapter-author', story.author);
    text('work-summary', story.summary);
    text('chapter-summary', story.summary);
    text('meta-rating', story.rating);
    text('meta-category', story.category);
    text('meta-warning', story.warning);
    text('meta-fandom', story.fandom);
    text('meta-relationship', story.relationship);
    text('meta-characters', story.characters);
    text('meta-additional', story.additionalTags);
    text('meta-language', story.language);
    text('meta-chapters', `${story.chapters.length}/?`);
    text('meta-words', story.chapters.reduce((total, chapter) => total + chapter.paragraphs.join(' ').trim().split(/\s+/).length, 0).toLocaleString('en-US'));
    document.title = `${story.title} | Fanfiction Reader`;
    const list = $('chapter-list');
    list.replaceChildren();
    story.chapters.forEach((chapter, index) => {
      const li = document.createElement('li');
      const link = document.createElement('a');
      link.href = `#chapter-${index + 1}`;
      link.textContent = `${index + 1}. ${chapter.title}`;
      li.appendChild(link);
      list.appendChild(li);
    });
  }

  function renderChapter(index) {
    const chapter = story.chapters[index];
    if (!chapter) return;
    text('chapter-title', chapter.title);
    text('chapter-position', `Chapter ${index + 1} of ${story.chapters.length}`);
    $('chapter-notes').hidden = !chapter.notes;
    text('chapter-notes-content', chapter.notes || '');
    const body = $('chapter-body');
    body.replaceChildren();
    chapter.paragraphs.forEach(paragraph => {
      const isPreview = paragraph.startsWith('[End of preview.');
      appendText(body, paragraph, isPreview ? 'preview-note' : '');
    });
    $('previous-chapter').disabled = index === 0;
    $('next-chapter').disabled = index === story.chapters.length - 1;
    $('previous-chapter').onclick = () => { if (index > 0) location.hash = `chapter-${index}`; };
    $('next-chapter').onclick = () => { if (index < story.chapters.length - 1) location.hash = `chapter-${index + 2}`; };
    try { localStorage.setItem('radioapple-reader:last-chapter', String(index + 1)); } catch (_) {}
  }

  function navigate() {
    const hash = location.hash.slice(1);
    const chapterMatch = /^chapter-(\d+)$/.exec(hash);
    const chapterIndex = chapterMatch ? Number(chapterMatch[1]) - 1 : -1;
    const isChapter = chapterIndex >= 0 && chapterIndex < story.chapters.length;
    $('work-view').hidden = isChapter;
    $('chapter-view').hidden = !isChapter;
    if (isChapter) renderChapter(chapterIndex);
    if (hash === 'chapters') {
      $('work-view').hidden = false;
      $('chapter-view').hidden = true;
      requestAnimationFrame(() => $('chapters').scrollIntoView());
    } else if (hash === 'about') {
      requestAnimationFrame(() => $('about').scrollIntoView());
    } else {
      window.scrollTo(0, 0);
    }
  }

  $('settings-trigger').addEventListener('click', () => {
    const panel = $('reader-settings');
    panel.hidden = !panel.hidden;
    $('settings-trigger').setAttribute('aria-expanded', String(!panel.hidden));
  });
  $('font-decrease').addEventListener('click', () => { settings.fontSize = Math.max(13, settings.fontSize - 1); updateSettings(); });
  $('font-increase').addEventListener('click', () => { settings.fontSize = Math.min(23, settings.fontSize + 1); updateSettings(); });
  $('theme-toggle').addEventListener('click', () => { settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; updateSettings(); });
  $('to-top').addEventListener('click', (e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  window.addEventListener('hashchange', navigate);
  updateSettings();
  populateMetadata();
  navigate();
})();
