# RadioApple Reader (mobile-first)

A static, **unofficial**, noncommercial one-story reader visually inspired by Archive of Our Own. It is not affiliated with AO3 or the Organization for Transformative Works (OTW).

## Try locally

Open `index.html` in a browser. The project uses no framework, package manager, build pipeline, server, login, analytics, or backend. For local server testing, run `python -m http.server 8000` in this folder, then visit `http://localhost:8000`.

## Edit the fanfic

Edit **`story.js`**. Update `title`, `author`, `summary`, metadata, and the first chapter's `paragraphs` array. Add chapter objects inside the `chapters` array to enable previous/next navigation. Notes are optional.

**The chapter content is a short preview, not the full approved story.** Also replace the provisional author, title, summary, rating/warnings, and tags before sharing. The site does not collect personal data or require login.

## Hosting

The same files work on GitHub Pages, Cloudflare Pages, Netlify, or any static web host. Deploy the folder without modifications, ensuring `index.html` is at the site's root.

## Reader functionality

- Responsive mobile-first layout; intentionally AO3-inspired appearance
- Chapter list and previous/next links
- Font size and dark mode preferences saved locally
- No third-party dependencies or tracking
- Print-friendly chapter view

## Scope

This is an **initial visual prototype**, not a pixel-validated copy of AO3. Verify on the reader's phone before publishing. No AO3 source code was copied verbatim; this site uses a separately written HTML/CSS/JS implementation.

## Publishing caution

Before choosing a host, check its current adult-content policy. GitHub Pages disallows certain sexually obscene content and GitHub Free Pages requires a public source repository. Do not assume explicit fiction is automatically permitted.
